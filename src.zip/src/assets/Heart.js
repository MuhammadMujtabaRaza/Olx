import React from 'react'

export default function Heart() {
    return(
        <div
        width="24px"
        height="24px"
      >
      </div>
    )
}