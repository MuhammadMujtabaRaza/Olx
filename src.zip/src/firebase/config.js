import firebase from 'firebase'
import 'firebase/auth' 
import 'firebase/firestore'
import 'firebase/storage' 

const firebaseConfig = {
  apiKey: "AIzaSyBbpzlT1ZJdlbsmWPtxlFRgiGkxdrQrkZ8",
  authDomain: "my-app-c77e8.firebaseapp.com",
  projectId: "my-app-c77e8",
  storageBucket: "my-app-c77e8.appspot.com",
  messagingSenderId: "692899361803",
  appId: "1:692899361803:web:382d6c04a7e0ecbb17030e"
};
export default firebase.initializeApp(firebaseConfig)
